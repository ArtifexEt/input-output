import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-top',
  templateUrl: './top.component.html',
  styleUrls: ['./top.component.css']
})
export class TopComponent implements OnInit {
  @Output() public siup: EventEmitter<void> = new EventEmitter<void>();
@Input() public finishButton = false;
  constructor() { }

  ngOnInit() {
  }

  handleClick(): void {
    this.siup.emit();
  }


}
