import { Component, OnInit, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-bottom',
  templateUrl: './bottom.component.html',
  styleUrls: ['./bottom.component.css']
})
export class BottomComponent implements OnInit , OnChanges {
  @Output() buttonsEnd: EventEmitter<void> = new EventEmitter<void>();
  @Input() public counter = 0;

  ngOnChanges(changes: SimpleChanges): void {
   if (this.counter > 3) {
      this.buttonsEnd.emit();
   }
  }

  constructor() { }

  ngOnInit() {
  }

}
